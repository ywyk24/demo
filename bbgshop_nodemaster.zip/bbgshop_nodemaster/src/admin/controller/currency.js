const Base = require('./base.js');

module.exports = class extends Base {
  async checkedAction() {
    console.log("定时任务__执行");
    console.log("12456798");
  }

};
