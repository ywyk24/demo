module.exports = class extends think.Logic {
  indexAction() {

  }
};
