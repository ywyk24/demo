// invoked in worker
